// main.js - Entry point for the application

// First load the diagnostics to check for circular dependencies
import './loader.js';

// Import game dependencies
import { initGame, handleCellClick } from './game.js';

// Initialize the game when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Log a message to confirm the DOM is fully loaded
    console.log('DOM fully loaded');
    
    try {
        // Set the global cell click handler to avoid circular dependencies
        window.handleCellClickFunction = handleCellClick;
        console.log('Cell click handler registered globally');
        
        // Initialize the game
        console.log('Starting game initialization...');
        initGame();
        
        // Debug log to confirm initialization
        console.log('Game initialized successfully');
    } catch (error) {
        console.error('Error in game initialization:', error);
    }
});
