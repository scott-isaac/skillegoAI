// game.js - Core game logic

import { BOARD_SIZE, PLAYER_COLORS } from './constants.js';
import { initializeBoard, updateTurnIndicator, highlightCell, clearValidMoves, movePiece } from './board.js';
import { makeCpuMove, getValidMovesForPiece } from './cpu.js';
import { debugLog } from './utils.js';
import { gameState } from './state.js';

function handleCellClick(row, col, cellElement) {
    debugLog(`handleCellClick called at (${row}, ${col})`);
    
    // If it's CPU's turn and CPU is enabled, ignore human clicks
    if (gameState.cpuEnabled && gameState.currentPlayer === gameState.cpuPlayer) {
        debugLog("Ignoring click during CPU turn");
        return;
    }
    
    const cell = gameState.board[row][col];
    
    // If no cell is selected and the clicked cell has a piece belonging to the current player
    if (!gameState.selectedCell && cell && !cellElement.classList.contains('covered') && cell.player === gameState.currentPlayer) {
        // Select the cell
        gameState.selectedCell = { row, col, piece: cell };
        cellElement.classList.add('selected');
        
        // Show valid moves
        showValidMoves(row, col);
    } 
    // If a cell is already selected
    else if (gameState.selectedCell) {
        // Check if the clicked cell is a valid move
        if (isValidMove(gameState.selectedCell.row, gameState.selectedCell.col, row, col)) {
            // Move the piece
            movePiece(gameState.selectedCell.row, gameState.selectedCell.col, row, col);
            
            // Switch turn
            gameState.currentPlayer = gameState.currentPlayer === 1 ? 2 : 1;
            updateTurnIndicator();
            
            // If CPU is enabled and it's CPU's turn, make a move
            if (gameState.cpuEnabled && gameState.currentPlayer === gameState.cpuPlayer) {
                debugLog("Scheduling CPU move after human's move");
                setTimeout(makeCpuMove, 800);
            }
        }
        
        // Clear selection and valid moves
        const selectedCellElement = document.querySelector(`.cell[data-row="${gameState.selectedCell.row}"][data-col="${gameState.selectedCell.col}"]`);
        if (selectedCellElement) {
            selectedCellElement.classList.remove('selected');
        }
        
        clearValidMoves();
        gameState.selectedCell = null;
    }
    // If no cell is selected and clicked on a covered piece
    else if (cell && cellElement.classList.contains('covered')) {
        // Uncover the piece
        cellElement.classList.remove('covered');
        cellElement.style.backgroundColor = gameState.playerColors[cell.player];
        cellElement.textContent = cell.emoji;
        
        // Switch turn
        gameState.currentPlayer = gameState.currentPlayer === 1 ? 2 : 1;
        updateTurnIndicator();
        
        // If CPU is enabled and it's CPU's turn, make a move
        if (gameState.cpuEnabled && gameState.currentPlayer === gameState.cpuPlayer) {
            debugLog("Scheduling CPU move after human uncovered a piece");
            setTimeout(makeCpuMove, 800);
        }
    }
}

function isValidMove(fromRow, fromCol, toRow, toCol) {
    // Check if the move is one of the valid moves
    return gameState.validMoves.some(move => move.row === toRow && move.col === toCol);
}

function showValidMoves(row, col) {
    const piece = gameState.board[row][col];
    gameState.validMoves = [];
    
    // Check all four directions (up, right, down, left)
    const directions = [
        [-1, 0], // up
        [0, 1],  // right
        [1, 0],  // down
        [0, -1]  // left
    ];
    
    directions.forEach(([dRow, dCol]) => {
        const newRow = row + dRow;
        const newCol = col + dCol;
        
        // Check if the new position is within the board
        if (newRow >= 0 && newRow < BOARD_SIZE && newCol >= 0 && newCol < BOARD_SIZE) {
            const targetCell = gameState.board[newRow][newCol];
            
            // Empty cell is a valid move
            if (!targetCell) {
                gameState.validMoves.push({ row: newRow, col: newCol });
                highlightCell(newRow, newCol, 'valid-move');
            } 
            // Cell with opponent's piece
            else if (targetCell.player !== piece.player && !document.querySelector(`.cell[data-row="${newRow}"][data-col="${newCol}"]`).classList.contains('covered')) {
                // Check capture rules
                if (
                    ((piece.power >= targetCell.power) && !(targetCell.type === 'mouse' && piece.type === 'dragon')) || 
                    (piece.type === 'mouse' && targetCell.type === 'dragon')
                ) {
                    gameState.validMoves.push({ row: newRow, col: newCol });
                    highlightCell(newRow, newCol, 'valid-capture');
                }
            }
        }
    });
}

function initGame() {
    console.log("Game initialization started");
    try {
        // Initialize the game
        initializeBoard();
        updateTurnIndicator();
        
        // Set up event listeners
        setupEventListeners();
        console.log("Game initialization completed successfully");
    } catch (error) {
        console.error("Error initializing game:", error);
        debugLog("Error initializing game: " + error.message);
    }
}

function setupEventListeners() {
    console.log("Setting up event listeners");
    const resetButton = document.getElementById('reset-button');
    const cpuEnabledCheckbox = document.getElementById('cpu-enabled');
    const cpuDifficultySelect = document.getElementById('cpu-difficulty');
    
    if (!resetButton || !cpuEnabledCheckbox || !cpuDifficultySelect) {
        console.error("Missing UI elements");
        debugLog("Error: Missing UI elements");
        return;
    }
    
    resetButton.addEventListener('click', () => {
        clearValidMoves();
        gameState.selectedCell = null;
        gameState.gameOver = false;
        initializeBoard();
        gameState.currentPlayer = 1;
        updateTurnIndicator();
        
        debugLog("Game reset. Player 1's turn.");
        
        // If CPU is enabled and it's player 2's turn, make CPU move
        if (gameState.cpuEnabled && gameState.currentPlayer === gameState.cpuPlayer) {
            debugLog("It's CPU's turn after reset, making a move");
            setTimeout(makeCpuMove, 500);
        }
    });

    cpuEnabledCheckbox.addEventListener('change', () => {
        gameState.cpuEnabled = cpuEnabledCheckbox.checked;
        cpuDifficultySelect.disabled = !cpuEnabledCheckbox.checked;
        
        debugLog(`CPU opponent ${gameState.cpuEnabled ? 'enabled' : 'disabled'}`);
        
        // If the game is in progress and it's CPU's turn, make a move
        if (gameState.cpuEnabled && gameState.currentPlayer === gameState.cpuPlayer) {
            debugLog("It's CPU's turn now, making a move");
            setTimeout(makeCpuMove, 500);
        }
    });

    cpuDifficultySelect.addEventListener('change', () => {
        gameState.cpuDifficulty = cpuDifficultySelect.value;
        debugLog(`CPU difficulty set to: ${gameState.cpuDifficulty}`);
    });
}

export { 
    handleCellClick, 
    showValidMoves, 
    isValidMove,
    initGame
};
