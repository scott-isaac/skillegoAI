// loader.js - Module loading diagnostics
console.log('Module loader diagnostics started');

// List of all modules to check
const modules = [
  './constants.js',
  './state.js',
  './board.js',
  './game.js',
  './cpu.js',
  './utils.js'
];

// Function to test importing a module
async function testModule(modulePath) {
  try {
    const module = await import(modulePath);
    console.log(`✓ Successfully loaded: ${modulePath}`);
    return { success: true, module };
  } catch (error) {
    console.error(`✗ Failed to load: ${modulePath}`, error);
    return { success: false, error };
  }
}

// Test all modules
async function testAllModules() {
  console.log('---------------------------------------');
  console.log('Testing all module imports:');
  
  for (const modulePath of modules) {
    await testModule(modulePath);
  }
  
  console.log('---------------------------------------');
  console.log('Module diagnostics complete');
}

testAllModules();
