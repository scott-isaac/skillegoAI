// test.js - Test script to verify module loading

console.log('Module loading test');

// Try to import from state.js
import { gameState } from './state.js';
console.log('gameState loaded successfully:', gameState);

// This script should run after all other modules are loaded
setTimeout(() => {
    console.log('Board status:', document.getElementById('board').children.length > 0 ? 'Board has children' : 'Board is empty');
    console.log('Window.handleCellClickFunction:', typeof window.handleCellClickFunction === 'function' ? 'Function found' : 'Function not found');
}, 1000);

export {};
