// cpu.js - CPU AI logic

import { BOARD_SIZE, PLAYER_COLORS } from './constants.js';
import { gameState } from './state.js';
import { updateTurnIndicator } from './board.js';
import { debugLog } from './utils.js';

function makeCpuMove() {
    debugLog("CPU is thinking...");
    
    if (!gameState.cpuEnabled || gameState.currentPlayer !== gameState.cpuPlayer || gameState.gameOver) {
        debugLog("CPU move cancelled: " + 
            (!gameState.cpuEnabled ? "CPU not enabled" : 
             gameState.currentPlayer !== gameState.cpuPlayer ? "Not CPU's turn" : 
             "Game is over"));
        return;
    }

    // First try to move an uncovered piece
    const canMove = hasValidMoves();
    
    if (canMove) {
        // If CPU can move, decide whether to move or uncover based on strategy
        const cpuMoveType = decideCpuMoveType();
        debugLog(`CPU chose to ${cpuMoveType} a piece (difficulty: ${gameState.cpuDifficulty})`);
        
        if (cpuMoveType === 'uncover') {
            uncoverRandomPiece();
        } else {
            moveRandomPiece();
        }
    } else {
        // If CPU has no valid moves, must uncover a piece
        debugLog("CPU has no valid moves, must uncover a piece");
        uncoverRandomPiece();
    }
}

function decideCpuMoveType() {
    // Count uncovered pieces for the CPU player
    let uncoveredPieces = 0;
    let coveredPieces = 0;

    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            const piece = gameState.board[row][col];
            if (piece && piece.player === gameState.cpuPlayer) {
                const cellElement = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
                if (!cellElement.classList.contains('covered')) {
                    uncoveredPieces++;
                } else {
                    coveredPieces++;
                }
            }
        }
    }

    // Different strategies based on difficulty
    switch (gameState.cpuDifficulty) {
        case 'easy':
            // Random choice with bias towards uncovering (more predictable)
            return Math.random() < 0.7 ? 'uncover' : 'move';
        
        case 'medium':
            // More strategic - uncover until we have some pieces, then start moving
            return (uncoveredPieces < 5) ? 'uncover' : 'move';
            
        case 'hard':
            // More adaptive strategy
            if (uncoveredPieces === 0) {
                return 'uncover';
            } else if (uncoveredPieces < 4) {
                // Uncover more pieces early
                return Math.random() < 0.7 ? 'uncover' : 'move';
            } else {
                // Focus on moving/attacking
                return 'move';
            }
            
        default:
            return Math.random() < 0.5 ? 'uncover' : 'move';
    }
}

function uncoverRandomPiece() {
    // Find all covered pieces (regardless of owner)
    const coveredPieces = [];
    
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            const piece = gameState.board[row][col];
            if (piece) {
                const cellElement = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
                if (cellElement && cellElement.classList.contains('covered')) {
                    coveredPieces.push({ row, col, element: cellElement });
                }
            }
        }
    }
    
    debugLog(`Found ${coveredPieces.length} covered pieces on the board`);
    
    if (coveredPieces.length === 0) {
        // No covered pieces, try moving instead
        debugLog("No covered pieces found, CPU has no valid moves");
        return;
    }
    
    // Choose a random covered piece
    const randomIndex = Math.floor(Math.random() * coveredPieces.length);
    const selectedPiece = coveredPieces[randomIndex];
    
    debugLog(`CPU will uncover piece at (${selectedPiece.row}, ${selectedPiece.col})`);
    
    // Directly uncover the piece without using handleCellClick to avoid potential issues
    const { row, col, element } = selectedPiece;
    if (element && gameState.board[row][col]) {
        debugLog("Directly uncovering CPU piece");
        const piece = gameState.board[row][col];
        
        // Uncover the piece
        element.classList.remove('covered');
        element.style.backgroundColor = PLAYER_COLORS[piece.player];
        element.textContent = piece.emoji;
        
        // Switch turn back to player 1
        debugLog("CPU's turn complete, switching to Player 1");
        gameState.currentPlayer = 1;
        updateTurnIndicator();
    } else {
        debugLog("Error: Failed to directly uncover piece - missing element or board data");
    }
}

function moveRandomPiece() {
    // Find all uncovered pieces for the CPU player
    const uncoveredPieces = [];
    
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            const piece = gameState.board[row][col];
            if (piece && piece.player === gameState.cpuPlayer) {
                const cellElement = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
                if (cellElement && !cellElement.classList.contains('covered')) {
                    // Check if this piece has valid moves
                    const validMoves = getValidMovesForPiece(row, col);
                    if (validMoves.length > 0) {
                        uncoveredPieces.push({ row, col, element: cellElement, validMoves });
                    }
                }
            }
        }
    }
    
    debugLog(`Found ${uncoveredPieces.length} uncovered CPU pieces with valid moves`);
    
    if (uncoveredPieces.length === 0) {
        // No movable pieces, must uncover something
        debugLog("No movable pieces found, falling back to uncovering a piece");
        uncoverRandomPiece();
        return;
    }
    
    // Choose a random piece to move
    const randomPieceIndex = Math.floor(Math.random() * uncoveredPieces.length);
    const selectedPiece = uncoveredPieces[randomPieceIndex];
    
    // Choose a random valid move for the selected piece
    const randomMoveIndex = Math.floor(Math.random() * selectedPiece.validMoves.length);
    const selectedMove = selectedPiece.validMoves[randomMoveIndex];
    
    debugLog(`CPU will move from (${selectedPiece.row}, ${selectedPiece.col}) to (${selectedMove.row}, ${selectedMove.col})`);
    
    // Directly move the piece instead of simulating clicks
    const fromRow = selectedPiece.row;
    const fromCol = selectedPiece.col;
    const toRow = selectedMove.row;
    const toCol = selectedMove.col;
    
    if (gameState.board[fromRow][fromCol]) {
        debugLog("Directly moving CPU piece");
        
        const fromPiece = gameState.board[fromRow][fromCol];
        const toPiece = gameState.board[toRow][toCol];
        
        // Update the board state
        gameState.board[toRow][toCol] = fromPiece;
        gameState.board[fromRow][fromCol] = null;
        
        // Update the visual representation
        const fromCell = document.querySelector(`.cell[data-row="${fromRow}"][data-col="${fromCol}"]`);
        const toCell = document.querySelector(`.cell[data-row="${toRow}"][data-col="${toCol}"]`);
        
        // Clear source cell
        if (fromCell) {
            fromCell.textContent = '';
            fromCell.style.backgroundColor = '#e0c9a6';  // Reset to board cell color
        }
        
        // Update target cell
        if (toCell) {
            toCell.textContent = fromPiece.emoji;
            toCell.style.backgroundColor = PLAYER_COLORS[fromPiece.player];
            toCell.classList.remove('covered', 'valid-move', 'valid-capture');
        }
        
        // Log capture if applicable
        if (toPiece) {
            debugLog(`CPU captured Player ${toPiece.player}'s ${toPiece.type} with a ${fromPiece.type}`);
        }
        
        // Switch turn back to player 1
        debugLog("CPU's turn complete, switching to Player 1");
        gameState.currentPlayer = 1;
        updateTurnIndicator();
    } else {
        debugLog("Error: Failed to move piece - missing board data");
    }
}

function getValidMovesForPiece(row, col) {
    const piece = gameState.board[row][col];
    const validMoves = [];
    
    // Check all four directions
    const directions = [
        [-1, 0], // up
        [0, 1],  // right
        [1, 0],  // down
        [0, -1]  // left
    ];
    
    directions.forEach(([dRow, dCol]) => {
        const newRow = row + dRow;
        const newCol = col + dCol;
        
        // Check if the new position is within the board
        if (newRow >= 0 && newRow < BOARD_SIZE && newCol >= 0 && newCol < BOARD_SIZE) {
            const targetCell = gameState.board[newRow][newCol];
            const targetElement = document.querySelector(`.cell[data-row="${newRow}"][data-col="${newCol}"]`);
            
            // Empty cell is a valid move
            if (!targetCell) {
                validMoves.push({ row: newRow, col: newCol });
            } 
            // Cell with opponent's piece that is not covered
            else if (targetCell.player !== piece.player && !targetElement.classList.contains('covered')) {
                // Check capture rules
                if (
                    ((piece.power >= targetCell.power) && !(targetCell.type === 'mouse' && piece.type === 'dragon')) || 
                    (piece.type === 'mouse' && targetCell.type === 'dragon')
                ) {
                    validMoves.push({ row: newRow, col: newCol });
                }
            }
        }
    });
    
    return validMoves;
}

function hasValidMoves() {
    // Check if CPU has any uncovered pieces that can move
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            const piece = gameState.board[row][col];
            if (piece && piece.player === gameState.cpuPlayer) {
                const cellElement = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
                if (cellElement && !cellElement.classList.contains('covered')) {
                    // Check if this piece has valid moves
                    const validMoves = getValidMovesForPiece(row, col);
                    if (validMoves.length > 0) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

export { 
    makeCpuMove, 
    getValidMovesForPiece, 
    hasValidMoves 
};
