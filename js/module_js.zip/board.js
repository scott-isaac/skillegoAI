// board.js - Board initialization and rendering

import { BOARD_SIZE, PIECES, PLAYER_COLORS } from './constants.js';
import { gameState } from './state.js';
import { debugLog } from './utils.js';

function initializeBoard() {
    console.log("Initializing board...");
    debugLog("Initializing game board");
    gameState.board = Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));
    const board = document.getElementById('board');
    if (!board) {
        console.error("Board element not found!");
        debugLog("ERROR: Board element not found!");
        return;
    }
    board.innerHTML = '';
    
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            const cell = document.createElement('div');
            cell.classList.add('cell', 'covered');
            cell.dataset.row = row;
            cell.dataset.col = col;
            cell.addEventListener('click', (e) => {
                // The actual handler will be set later to avoid circular dependencies
                if (window.handleCellClickFunction) {
                    window.handleCellClickFunction(row, col, cell);
                }
            });
            board.appendChild(cell);
        }
    }

    // Assign pieces to players randomly
    assignPieces();
}

function assignPieces() {
    const allPieces = [];

    // Add pieces for both players
    for (let player = 1; player <= 2; player++) {
        PIECES.forEach(piece => {
            for (let i = 0; i < piece.quantity; i++) {
                allPieces.push({ ...piece, player });
            }
        });
    }

    // Shuffle pieces
    allPieces.sort(() => Math.random() - 0.5);

    // Place pieces on the board
    let index = 0;
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            if (index < allPieces.length) {
                gameState.board[row][col] = allPieces[index];
                index++;
            }
        }
    }
}

function updateTurnIndicator() {
    const turnIndicator = document.getElementById('turn-indicator');
    turnIndicator.textContent = `Player ${gameState.currentPlayer}'s Turn`;
    turnIndicator.style.backgroundColor = PLAYER_COLORS[gameState.currentPlayer];
}

function highlightCell(row, col, className) {
    const cellElement = document.querySelector(`.cell[data-row="${row}"][data-col="${col}"]`);
    if (cellElement) {
        cellElement.classList.add(className);
    }
}

function clearValidMoves() {
    document.querySelectorAll('.valid-move, .valid-capture').forEach(cell => {
        cell.classList.remove('valid-move', 'valid-capture');
    });
    gameState.validMoves = [];
}

function movePiece(fromRow, fromCol, toRow, toCol) {
    const fromPiece = gameState.board[fromRow][fromCol];
    const toPiece = gameState.board[toRow][toCol];
    
    // Update the board state
    gameState.board[toRow][toCol] = fromPiece;
    gameState.board[fromRow][fromCol] = null;
    
    // Update the visual representation
    const fromCell = document.querySelector(`.cell[data-row="${fromRow}"][data-col="${fromCol}"]`);
    const toCell = document.querySelector(`.cell[data-row="${toRow}"][data-col="${toCol}"]`);
    
    // Clear source cell
    fromCell.textContent = '';
    fromCell.style.backgroundColor = '#e0c9a6';  // Reset to board cell color
    
    // Update target cell
    toCell.textContent = fromPiece.emoji;
    toCell.style.backgroundColor = PLAYER_COLORS[fromPiece.player];
    toCell.classList.remove('covered', 'valid-move', 'valid-capture');
    
    // Log capture if applicable
    if (toPiece) {
        debugLog(`Player ${fromPiece.player} captured Player ${toPiece.player}'s ${toPiece.type} with a ${fromPiece.type}`);
    }
}

export { 
    initializeBoard, 
    updateTurnIndicator, 
    highlightCell, 
    clearValidMoves, 
    movePiece 
};
