// state.js - Game state management

import { PLAYER_COLORS } from './constants.js';

// Game state object
const gameState = {
    board: [],
    currentPlayer: 1,
    selectedCell: null,
    validMoves: [],
    playerColors: PLAYER_COLORS,
    cpuEnabled: false,
    cpuDifficulty: 'medium',
    cpuPlayer: 2, // CPU is always player 2
    gameOver: false
};

export { gameState };
