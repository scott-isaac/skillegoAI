// constants.js - Game constants

const BOARD_SIZE = 6;
const PIECES = [
    { type: 'mouse', power: 1, quantity: 6, emoji: '🐭' },
    { type: 'cat', power: 2, quantity: 4, emoji: '😸' },
    { type: 'wolf', power: 3, quantity: 4, emoji: '🐶' },
    { type: 'bear', power: 4, quantity: 2, emoji: '🧙‍♂️' },
    { type: 'eagle', power: 5, quantity: 1, emoji: '🤖' },
    { type: 'dragon', power: 6, quantity: 1, emoji: '👑' },
];

const PLAYER_COLORS = {
    1: '#ff9999', // Softer red
    2: '#9999ff'  // Softer blue
};

export { BOARD_SIZE, PIECES, PLAYER_COLORS };
